const PORTAL = 'https://blast-buddies-portal.vercel.app';
const DEFAULTS = {
  myClanId: '', rivalClanId: '', playerId: '',
  checkMinutes: 2, minAwayMinutes: 30,
  outlineDistance: 500, alertDistance: 1000, outlineWhen: 'ahead',
  outlineColor: '#ff2d2d', outlineWidth: 4,
  f: { overlay: true, hourly: true, compare: true, away: true, overtake: true, bestHours: true, session: true, records: true }
};
async function getSettings() {
  const { settings = {} } = await chrome.storage.sync.get('settings');
  return { ...DEFAULTS, ...settings, f: { ...DEFAULTS.f, ...(settings.f || {}) } };
}
const fmt = n => (n == null || n < 0) ? '—' : '+' + n.toLocaleString();
