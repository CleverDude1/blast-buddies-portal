importScripts('shared.js');
const HOUR = 3600e3;

async function fetchData(s, since) {
  const q = new URLSearchParams({ mode: 'extension', clan: s.myClanId, rival: s.rivalClanId, player: s.playerId });
  if (since) q.set('since', since);
  const r = await fetch(`${PORTAL}/api/stats?${q}`);
  if (!r.ok) throw new Error('portal ' + r.status);
  return r.json();
}
const notify = (title, message) =>
  chrome.notifications.create({ type: 'basic', iconUrl: 'icon128.png', title, message });
const short = n => n == null ? '' : n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + 'k' : String(n);
const diff = (a, b) => (a == null || b == null) ? null : a - b;

function peakText(byHour) {
  if (!Array.isArray(byHour) || byHour.length !== 24) return '';
  let best = 0, bestK = 0;
  for (let k = 0; k < 24; k++) {
    const v = byHour[new Date(Date.now() + k * HOUR).getUTCHours()] || 0;
    if (v > best) { best = v; bestK = k; }
  }
  if (!best) return '';
  if (bestK === 0) return 'Peak clan gains: now';
  const at = new Date(Date.now() + bestK * HOUR).toLocaleTimeString([], { hour: 'numeric' });
  return `Peak clan gains in ${bestK}h (${at})`;
}

async function check() {
  const s = await getSettings();
  if (!s.myClanId) return;
  let d;
  try { d = await fetchData(s); } catch (e) { return; }
  const now = Date.now();
  let { hist = [], st = {} } = await chrome.storage.local.get(['hist', 'st']);

  // hourly gains from local snapshots
  hist.push({ t: now, m: d.mine?.kills, r: d.rival?.kills, p: d.player?.kills });
  hist = hist.filter(h => now - h.t <= HOUR + 15 * 60e3);
  const base = hist.find(h => now - h.t <= HOUR) || hist[0];
  const gain = {
    m: diff(d.mine?.kills, base.m), r: diff(d.rival?.kills, base.r), p: diff(d.player?.kills, base.p),
    mins: Math.round((now - base.t) / 60e3)
  };

  // red outline + overtake alerts
  const gap = (d.mine && d.rival) ? d.mine.kills - d.rival.kills : null;
  const rt = d.rival?.tag || 'Rival';
  let near = false;
  if (gap !== null && s.f.overtake) {
    near = s.outlineWhen === 'both' ? Math.abs(gap) <= s.outlineDistance
                                    : gap >= 0 && gap <= s.outlineDistance;
    if (st.gap > 0 && gap < 0) notify('Overtaken', `${rt} just passed your clan.`);
    else if (st.gap < 0 && gap > 0) notify('You took the lead', `Your clan just passed ${rt}.`);
    const inAlert = gap >= 0 && gap <= s.alertDistance;
    if (inAlert && !st.inAlert) notify('Rival closing in', `${rt} is ${gap.toLocaleString()} kills behind you.`);
    st.inAlert = inAlert;
  }
  st.gap = gap;

  // level 100 + record alerts
  if (s.f.records && Array.isArray(d.events)) {
    const ids = d.events.map(e => e.id);
    if (!st.seen) st.seen = ids;
    else {
      d.events.filter(e => !st.seen.includes(e.id)).slice(0, 3)
        .forEach(e => notify(e.type === 'level100' ? 'New level 100' : 'New record', e.text));
      st.seen = [...new Set([...st.seen, ...ids])].slice(-100);
    }
  }

  // session summary: ends after 10 minutes without game activity
  const { act = {} } = await chrome.storage.local.get('act');
  if (s.f.session && act.sess && now - act.lastPing > 10 * 60e3) {
    const mins = Math.round((act.lastPing - act.sess.t) / 60e3);
    const lines = [`${Math.floor(mins / 60)}h ${mins % 60}m played`];
    if (act.sess.p != null && d.player) lines.push(`You ${fmt(d.player.kills - act.sess.p)} kills`);
    if (act.sess.m != null && d.mine) lines.push(`Clan ${fmt(d.mine.kills - act.sess.m)}`);
    notify('Session summary', lines.join(' | '));
    const cur = (await chrome.storage.local.get('act')).act || {};
    delete cur.sess;
    await chrome.storage.local.set({ act: cur });
  }

  // toolbar badge
  const b = s.f.hourly ? (gain.p ?? gain.m) : null;
  chrome.action.setBadgeText({ text: b != null ? short(b) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#2f6b46' });

  const view = { ts: now, near, gap, gain, tags: { m: d.mine?.tag, r: d.rival?.tag },
                 peak: s.f.bestHours ? peakText(d.byHour) : '' };
  await chrome.storage.local.set({ hist, st, view });
}

// game page messages: hello (page load) and ping (every minute while visible)
chrome.runtime.onMessage.addListener((msg, sender) => {
  (async () => {
    const now = Date.now();
    const { act = {}, hist = [] } = await chrome.storage.local.get(['act', 'hist']);
    const last = hist[hist.length - 1];
    if (msg.type === 'hello' && act.lastPing) {
      const s = await getSettings();
      const gapMs = now - act.lastPing;
      if (s.f.away && s.myClanId && gapMs >= s.minAwayMinutes * 60e3) {
        try {
          const d = await fetchData(s, act.lastPing);
          if (d.since) {
            const m = Math.round(gapMs / 60e3);
            const lines = [`While you were away (${m >= 120 ? Math.round(m / 60) + 'h' : m + 'm'})`];
            if (d.mine) lines.push(`${d.mine.tag || 'Your clan'}: ${fmt(diff(d.mine.kills, d.since.mine))} kills`);
            if (d.rival) lines.push(`${d.rival.tag || 'Rival'}: ${fmt(diff(d.rival.kills, d.since.rival))} kills`);
            if (d.player) lines.push(`You: ${fmt(diff(d.player.kills, d.since.player))} kills`);
            chrome.tabs.sendMessage(sender.tab.id, { type: 'away', lines });
          }
        } catch (e) {}
      }
    }
    if (!act.sess || now - act.lastPing > 10 * 60e3) act.sess = { t: now, p: last?.p, m: last?.m };
    act.lastPing = now;
    await chrome.storage.local.set({ act });
  })();
});

async function schedule() {
  const s = await getSettings();
  chrome.alarms.create('check', { periodInMinutes: Math.max(1, Number(s.checkMinutes) || 2) });
  check();
}
chrome.runtime.onInstalled.addListener(schedule);
chrome.runtime.onStartup.addListener(schedule);
chrome.alarms.onAlarm.addListener(a => a.name === 'check' && check());
chrome.storage.onChanged.addListener((c, area) => area === 'sync' && c.settings && schedule());
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
