# Blast Buddies Tracker Companion (unofficial)

## Install (testing)
1. Open chrome://extensions and turn on Developer mode.
2. Click "Load unpacked" and pick this folder.
3. In manifest.json, replace REPLACE-WITH-GAME-DOMAIN with the game's domain, then reload the extension.
4. Click the extension icon, enter your clan ID, rival clan ID and player ID.

## Portal endpoint the extension calls
GET {PORTAL}/api/stats?mode=extension&clan=ID&rival=ID&player=ID[&since=unixMs]
Returns:
{
  "mine":   { "tag": "FT", "kills": 42844 },        // clan monthlyKills
  "rival":  { "tag": "XX", "kills": 41900 },
  "player": { "kills": 11108 },                     // or null
  "since":  { "mine": n, "rival": n, "player": n }, // values at `since` (nearest snapshot), only when since is sent
  "byHour": [24 numbers],                           // avg clan gain per UTC hour 0-23
  "events": [{ "id": "...", "type": "level100"|"record", "text": "..." }]
}
