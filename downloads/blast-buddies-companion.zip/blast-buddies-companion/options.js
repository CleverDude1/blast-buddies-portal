const getPath = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
const setPath = (o, p, v) => { const ks = p.split('.'), last = ks.pop(); ks.reduce((a, k) => a[k], o)[last] = v; };
(async () => {
  const s = await getSettings();
  const flash = () => { const el = document.getElementById('saved'); el.style.opacity = 1; setTimeout(() => (el.style.opacity = 0), 900); };
  document.querySelectorAll('[data-k]').forEach(i => {
    const v = getPath(s, i.dataset.k);
    if (i.type === 'checkbox') i.checked = v; else i.value = v;
    i.onchange = async () => {
      setPath(s, i.dataset.k, i.type === 'checkbox' ? i.checked : i.type === 'number' ? Number(i.value) : i.value.trim());
      await chrome.storage.sync.set({ settings: s });
      flash();
    };
  });
})();
