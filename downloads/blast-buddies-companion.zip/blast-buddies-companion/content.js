(() => {
  const mk = css => { const e = document.createElement('div'); e.style.cssText = css; return e; };
  const outline = mk('position:fixed;inset:0;pointer-events:none;z-index:2147483647;display:none');
  const chip = mk('position:fixed;top:8px;right:8px;pointer-events:none;z-index:2147483647;display:none;white-space:pre;font:12px/1.4 system-ui,sans-serif;background:rgba(10,30,20,.88);color:#d7f5e0;border:1px solid #2f6b46;border-radius:8px;padding:6px 10px');
  const toast = mk('position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483647;display:none;white-space:pre;font:13px/1.5 system-ui,sans-serif;background:#0d2418;color:#d7f5e0;border:1px solid #2f6b46;border-radius:10px;padding:10px 16px;cursor:pointer');
  document.documentElement.append(outline, chip, toast);
  toast.onclick = () => (toast.style.display = 'none');

  async function render() {
    const s = await getSettings();
    const { view } = await chrome.storage.local.get('view');
    if (!view) return;
    outline.style.display = s.f.overtake && view.near ? 'block' : 'none';
    outline.style.boxShadow = `inset 0 0 0 ${s.outlineWidth}px ${s.outlineColor}`;
    const lines = [], g = view.gain;
    const age = g.mins < 55 ? ` (${g.mins}m)` : '';
    if (s.f.hourly && g.p != null) lines.push(`You: ${fmt(g.p)} per hour${age}`);
    if (s.f.compare && view.gap != null) {
      lines.push(`${view.tags.m || 'Clan'} ${fmt(g.m)}/h vs ${view.tags.r || 'Rival'} ${fmt(g.r)}/h`);
      lines.push(`Gap: ${view.gap >= 0 ? '+' : ''}${view.gap.toLocaleString()} kills`);
    }
    if (view.peak) lines.push(view.peak);
    chip.textContent = lines.join('\n');
    chip.style.display = s.f.overlay && lines.length ? 'block' : 'none';
  }

  chrome.runtime.onMessage.addListener(m => {
    if (m.type !== 'away') return;
    toast.textContent = m.lines.join('\n');
    toast.style.display = 'block';
    setTimeout(() => (toast.style.display = 'none'), 15000);
  });
  const send = type => { try { chrome.runtime.sendMessage({ type }).catch(() => {}); } catch (e) {} };
  send('hello');
  setInterval(() => !document.hidden && send('ping'), 60000);
  chrome.storage.onChanged.addListener(render);
  render();
})();
